package com.formacion;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EscuelaSmApplication {

	public static void main(String[] args) {
		SpringApplication.run(EscuelaSmApplication.class, args);
	}

}
